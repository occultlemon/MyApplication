﻿/*!
子女兄弟树main.cpp文件
 */

#include "test.h"


using namespace std;


int main() {

	TestChildSiblingTreeCreateTreeByStr();

	TestChildSiblingTreeDepth();

	TestChildSiblingTreeNodeCount();

	TestChildSiblingTreePostOrder();

	TestChildSiblingTreePreOrder();

	TestChildSiblingTreeLevelOrder();

	return 0;
}
