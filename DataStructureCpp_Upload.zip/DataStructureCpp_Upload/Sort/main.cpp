﻿/*!
测试demo演示
 */

#include "test.h"


int main() {

	TestBubbleSort();

	TestSelectSort();

	TestInsertSort();

    TestMergeSort();

	TestMergeSortNonRecursive();

	TestQuickSort();

	TestHeapSort();

	return 0;
}
