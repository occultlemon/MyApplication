﻿/*!
字符串匹配Demo演示
 */

#include "test.h"


int main() {

    TestStringBaseFunctions();

    TestBruteForceMatch();

    TestKmpMatch();

    TestKmpMatchCyberDash();

  return 0;
}