/*!
广义表Demo演示
 */

#include "test.h"


using namespace std;


int main() {

  TestDepth();

  TestLength();

  TestSimpleGenListDepth();

  return 0;
}