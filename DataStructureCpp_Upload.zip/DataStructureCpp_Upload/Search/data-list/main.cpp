﻿
#include "test.h"


using namespace std;

int main() {

	TestSearchListSeqSearch();

	TestSearchListSeqSearchRecursive();

	TestSortedListSeqSearch();

	TestSortedListBinarySearch();

	TestSortedListBinarySearchRecursive();

	return 0;
}
