﻿/*!
队列demo演示
 */

#include "test.h"


int main() {

	TestGetSize();

	TestEnQueue();

	TestDeQueue();

	TestGetFrontAndGetRear();

	TestIsEmpty();

	TestOperatorCout();

	return 0;
}
